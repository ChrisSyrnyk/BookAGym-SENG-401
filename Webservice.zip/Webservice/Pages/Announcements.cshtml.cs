using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Webservice.Pages
{
    public class AnnoucementsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
